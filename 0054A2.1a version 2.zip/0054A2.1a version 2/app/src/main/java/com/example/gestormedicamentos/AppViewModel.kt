package com.example.gestormedicamentos

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    val medicamentos = dao.medicamentos()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val tomas = dao.tomas()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun agregarMedicamento(m: Medicamento) = viewModelScope.launch {
        val id = dao.insertarMedicamento(m)
        Recordatorios.programar(getApplication(), m.copy(id = id))
    }

    fun registrarToma(t: Toma, alTerminar: (String?) -> Unit) = viewModelScope.launch {
        alTerminar(dao.registrarToma(t))
    }

    fun reponer(id: Long, n: Int) = viewModelScope.launch { dao.reponer(id, n) }

    fun guardarSensacion(id: Long, s: String?) = viewModelScope.launch { dao.actualizarSensacion(id, s) }
}
