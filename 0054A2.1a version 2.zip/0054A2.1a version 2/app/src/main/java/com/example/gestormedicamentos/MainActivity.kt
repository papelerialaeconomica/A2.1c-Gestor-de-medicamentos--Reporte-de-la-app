@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.gestormedicamentos

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Verde = Color(0xFF2E7D32)
private val Rojo = Color(0xFFC62828)
private val Naranja = Color(0xFFEF6C00)

private val esquema = lightColorScheme(
    primary = Color(0xFF1565C0), onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF), onPrimaryContainer = Color(0xFF001B3E),
    secondary = Color(0xFF00897B),
    background = Color(0xFFF6F8FC), surface = Color(0xFFF6F8FC),
    surfaceVariant = Color(0xFFE3E8F2), error = Rojo
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Recordatorios.crearCanal(this)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        // Asegura que los recordatorios de todos los medicamentos estén programados
        val app = applicationContext
        CoroutineScope(Dispatchers.IO).launch { Recordatorios.programarTodos(app) }
        setContent { MaterialTheme(colorScheme = esquema) { App() } }
    }
}

private val fmtFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
private val fmtHora = SimpleDateFormat("HH:mm", Locale.getDefault())
private val fmtCompleto = SimpleDateFormat("dd/MM/yyyy  HH:mm", Locale.getDefault())

fun elegirFecha(c: Context, actual: Long, ok: (Long) -> Unit) {
    val cal = Calendar.getInstance().apply { timeInMillis = actual }
    DatePickerDialog(c, { _, y, m, d ->
        cal.set(y, m, d); ok(cal.timeInMillis)
    }, cal[Calendar.YEAR], cal[Calendar.MONTH], cal[Calendar.DAY_OF_MONTH]).show()
}

fun elegirHora(c: Context, h: Int, m: Int, ok: (Int, Int) -> Unit) =
    TimePickerDialog(c, { _, hh, mm -> ok(hh, mm) }, h, m, true).show()

// ------------------------------------------------------------------ Estructura general

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val ruta = nav.currentBackStackEntryAsState().value?.destination?.route ?: "botiquin"
    val snackbar = remember { SnackbarHostState() }
    var agregar by remember { mutableStateOf(false) }
    val destinos = listOf(
        Triple("botiquin", "Botiquín", Icons.Default.Home),
        Triple("registrar", "Registrar toma", Icons.Default.Add),
        Triple("historial", "Historial", Icons.AutoMirrored.Filled.List)
    )
    val titulo = destinos.firstOrNull { it.first == ruta }?.second ?: ""

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(titulo, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                destinos.forEach { (r, t, icono) ->
                    NavigationBarItem(
                        selected = ruta == r,
                        onClick = { nav.navigate(r) { popUpTo("botiquin"); launchSingleTop = true } },
                        icon = { Icon(icono, contentDescription = t) },
                        label = { Text(t) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (ruta == "botiquin") ExtendedFloatingActionButton(
                onClick = { agregar = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Agregar medicamento") }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { p ->
        NavHost(nav, "botiquin", Modifier.padding(p)) {
            composable("botiquin") { Botiquin(vm, agregar) { agregar = false } }
            composable("registrar") {
                RegistrarToma(vm, snackbar) { nav.navigate("historial") { popUpTo("botiquin") } }
            }
            composable("historial") { Historial(vm) }
        }
    }
}

@Composable
fun Mensaje(texto: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
        Text(texto, textAlign = TextAlign.Center, fontSize = 16.sp)
    }
}

@Composable
fun Etiqueta(texto: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.15f)) {
        Text(
            texto, Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
        )
    }
}

// ------------------------------------------------------------------ Botiquín

@Composable
fun Botiquin(vm: AppViewModel, mostrarDialogo: Boolean, cerrar: () -> Unit) {
    val meds by vm.medicamentos.collectAsState()
    var ahora by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var reponer by remember { mutableStateOf<Medicamento?>(null) }
    LaunchedEffect(Unit) {
        while (true) { delay(15_000); ahora = System.currentTimeMillis() }   // actualiza el tiempo restante
    }

    if (meds.isEmpty()) {
        Mensaje("Aún no tienes medicamentos.\nToca \"Agregar medicamento\" para registrar el primero.")
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ProximaToma(meds, ahora) }
            items(meds) { m -> TarjetaMedicamento(m, ahora) { reponer = m } }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }
    if (mostrarDialogo) AgregarMedicamento(cerrar) { vm.agregarMedicamento(it); cerrar() }
    reponer?.let { m ->
        ReponerDialog(m, { reponer = null }) { n -> vm.reponer(m.id, n); reponer = null }
    }
}

@Composable
fun ProximaToma(meds: List<Medicamento>, ahora: Long) {
    val ctx = LocalContext.current
    val prox = meds.minByOrNull { msHastaProximaToma(it.horaProgramada, ahora) }
    if (prox != null) {
        val ms = msHastaProximaToma(prox.horaProgramada, ahora)
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Próxima toma", style = MaterialTheme.typography.labelLarge)
                Text("En ${textoTiempoRestante(ms)}", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("${prox.nombre} · ${prox.dosis} · a las ${prox.horaProgramada}")
                TextButton(
                    onClick = { Recordatorios.mostrarNotificacion(ctx, prox) },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary)
                ) { Text("Probar notificación") }
            }
        }
    }
}

@Composable
fun TarjetaMedicamento(m: Medicamento, ahora: Long, alReponer: () -> Unit) {
    val base = if (m.existenciasIniciales > 0) m.existenciasIniciales else maxOf(m.existencias, 1)
    val progreso = (m.existencias.toFloat() / base).coerceIn(0f, 1f)
    val pocas = m.existencias <= m.pastillasPorToma * 3
    val colorExistencias = if (pocas) Rojo else MaterialTheme.colorScheme.primary

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(m.nombre, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    if (m.tipo.isNotBlank()) Text(m.tipo, color = MaterialTheme.colorScheme.primary)
                }
                Etiqueta(m.dosis, MaterialTheme.colorScheme.primary)
            }
            LinearProgressIndicator(
                progress = { progreso },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = colorExistencias,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Quedan ${m.existencias} pastillas", color = colorExistencias,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (pocas) Text(
                        if (m.existencias == 0) "Sin existencias" else "Quedan pocas",
                        color = Rojo, style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedButton(onClick = alReponer) { Text("Reponer") }
            }
            HorizontalDivider()
            Text(
                "Próxima toma en ${textoTiempoRestante(msHastaProximaToma(m.horaProgramada, ahora))} · ${m.horaProgramada}",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun ReponerDialog(m: Medicamento, cerrar: () -> Unit, guardar: (Int) -> Unit) {
    var n by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = cerrar,
        title = { Text("Reponer ${m.nombre}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ahora tienes ${m.existencias} pastillas.")
                OutlinedTextField(
                    n, { n = it.filter(Char::isDigit) }, label = { Text("Pastillas que agregas") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = n.toIntOrNull()
                if (v != null && v > 0) guardar(v)
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = cerrar) { Text("Cancelar") } }
    )
}

@Composable
fun AgregarMedicamento(cerrar: () -> Unit, guardar: (Medicamento) -> Unit) {
    val ctx = LocalContext.current
    var nombre by remember { mutableStateOf("") }
    var tipo by remember { mutableStateOf("") }
    var dosis by remember { mutableStateOf("") }
    var existencias by remember { mutableStateOf("") }
    var porToma by remember { mutableStateOf("1") }
    var hora by remember { mutableStateOf("08:00") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = cerrar,
        title = { Text("Nuevo medicamento") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nombre, { nombre = it }, label = { Text("Nombre") }, singleLine = true)
                OutlinedTextField(tipo, { tipo = it }, label = { Text("Tipo de medicamento") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Analgésico", "Antibiótico", "Antiinflamatorio", "Vitamina").forEach {
                        AssistChip(onClick = { tipo = it }, label = { Text(it) })
                    }
                }
                OutlinedTextField(dosis, { dosis = it }, label = { Text("Dosis (ej. 500 mg)") }, singleLine = true)
                OutlinedTextField(existencias, { existencias = it.filter(Char::isDigit) },
                    label = { Text("Existencias (pastillas)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(porToma, { porToma = it.filter(Char::isDigit) },
                    label = { Text("Pastillas por toma") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedButton(onClick = {
                    elegirHora(ctx, 8, 0) { h, m -> hora = "%02d:%02d".format(h, m) }
                }) { Text("Hora del recordatorio: $hora") }
                error?.let { Text(it, color = Rojo) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val ex = existencias.toIntOrNull()
                val pt = porToma.toIntOrNull()
                if (nombre.isBlank() || dosis.isBlank() || ex == null || pt == null || pt < 1)
                    error = "Completa todos los campos"
                else guardar(
                    Medicamento(
                        nombre = nombre.trim(), tipo = tipo.trim(), dosis = dosis.trim(),
                        existencias = ex, existenciasIniciales = ex,
                        pastillasPorToma = pt, horaProgramada = hora
                    )
                )
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = cerrar) { Text("Cancelar") } }
    )
}

// ------------------------------------------------------------------ Registrar toma

private val opcionesSentir = listOf("😀 Bien", "😐 Regular", "🤒 Mal")

@Composable
fun Seccion(titulo: String, contenido: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary)
            contenido()
        }
    }
}

@Composable
fun RegistrarToma(vm: AppViewModel, snackbar: SnackbarHostState, alExito: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val meds by vm.medicamentos.collectAsState()
    val tomas by vm.tomas.collectAsState()

    var selId by rememberSaveable { mutableStateOf<Long?>(null) }
    var expandido by remember { mutableStateOf(false) }
    var fecha by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var estado by rememberSaveable { mutableStateOf("TOMADA") }
    var motivo by remember { mutableStateOf("") }
    var sentirChip by remember { mutableStateOf("") }
    var comentario by remember { mutableStateOf("") }
    var pendiente by remember { mutableStateOf<Toma?>(null) }
    val sel = meds.firstOrNull { it.id == selId }

    val guardar: (Toma) -> Unit = { t ->
        vm.registrarToma(t) { e ->
            if (e == null) {
                Toast.makeText(ctx, "Toma registrada correctamente", Toast.LENGTH_SHORT).show()
                selId = null; motivo = ""; sentirChip = ""; comentario = ""
                fecha = System.currentTimeMillis()
                alExito()
            } else scope.launch { snackbar.showSnackbar(e) }
        }
    }

    if (meds.isEmpty()) {
        Mensaje("Debes tener al menos un medicamento registrado en el Botiquín para registrar una toma.")
    } else {
        Column(
            Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Seccion("Medicamento") {
                ExposedDropdownMenuBox(expanded = expandido, onExpandedChange = { expandido = it }) {
                    OutlinedTextField(
                        value = sel?.nombre ?: "", onValueChange = {}, readOnly = true,
                        label = { Text("Selecciona el medicamento") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expandido) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expandido, onDismissRequest = { expandido = false }) {
                        meds.forEach { m ->
                            DropdownMenuItem(
                                text = { Text(if (m.tipo.isBlank()) m.nombre else "${m.nombre} (${m.tipo})") },
                                onClick = { selId = m.id; expandido = false }
                            )
                        }
                    }
                }
                // La dosis se carga sola, no se escribe ni se puede cambiar
                sel?.let {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Etiqueta("Dosis: ${it.dosis}", MaterialTheme.colorScheme.primary)
                        Etiqueta("Quedan ${it.existencias} pastillas",
                            if (it.existencias <= it.pastillasPorToma * 3) Rojo else Verde)
                    }
                }
            }

            Seccion("Fecha y hora") {
                Text(fmtCompleto.format(Date(fecha)), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { elegirFecha(ctx, fecha) { fecha = it } }) { Text("Cambiar fecha") }
                    OutlinedButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = fecha }
                        elegirHora(ctx, c[Calendar.HOUR_OF_DAY], c[Calendar.MINUTE]) { h, m ->
                            c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m); fecha = c.timeInMillis
                        }
                    }) { Text("Cambiar hora") }
                }
            }

            Seccion("Estado de la toma") {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    listOf("TOMADA" to "Tomada", "OMITIDA" to "Omitida").forEachIndexed { i, (v, t) ->
                        SegmentedButton(
                            selected = estado == v, onClick = { estado = v },
                            shape = SegmentedButtonDefaults.itemShape(i, 2)
                        ) { Text(t) }
                    }
                }
                if (estado == "OMITIDA") {
                    OutlinedTextField(motivo, { motivo = it }, label = { Text("Motivo de la omisión") },
                        modifier = Modifier.fillMaxWidth())
                } else {
                    Text("¿Cómo te sentiste después de tomarlo?")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        opcionesSentir.forEach {
                            FilterChip(
                                selected = sentirChip == it,
                                onClick = { sentirChip = if (sentirChip == it) "" else it },
                                label = { Text(it) }
                            )
                        }
                    }
                    OutlinedTextField(comentario, { comentario = it }, label = { Text("Comentario (opcional)") },
                        modifier = Modifier.fillMaxWidth())
                }
            }

            Button(
                onClick = {
                    val m = sel
                    when {
                        m == null -> scope.launch { snackbar.showSnackbar("Selecciona un medicamento") }
                        estado == "OMITIDA" && motivo.isBlank() ->
                            scope.launch { snackbar.showSnackbar("Indica el motivo de la omisión") }
                        else -> {
                            val sentir = listOf(sentirChip, comentario.trim()).filter { it.isNotBlank() }
                                .joinToString(" - ").ifBlank { null }
                            val t = Toma(
                                idMedicamento = m.id, nombreMedicamento = m.nombre, dosis = m.dosis,
                                fechaHora = fecha, estado = estado,
                                motivoOmision = if (estado == "OMITIDA") motivo.trim() else null,
                                fueraDeHorario = esFueraDeHorario(m.horaProgramada, fecha),
                                sensacion = if (estado == "TOMADA") sentir else null
                            )
                            // Evita repetir la dosis por error: avisa si ya hay una toma reciente del mismo medicamento
                            val repetida = estado == "TOMADA" && tomas.any {
                                it.idMedicamento == m.id && it.estado == "TOMADA" &&
                                    Math.abs(it.fechaHora - fecha) < 3_600_000L
                            }
                            if (repetida) pendiente = t else guardar(t)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Guardar toma")
            }
        }
    }

    pendiente?.let { t ->
        AlertDialog(
            onDismissRequest = { pendiente = null },
            title = { Text("¿Repetir la dosis?") },
            text = { Text("Ya registraste una toma de ${t.nombreMedicamento} hace menos de 1 hora. ¿Quieres registrar otra?") },
            confirmButton = { TextButton(onClick = { pendiente = null; guardar(t) }) { Text("Sí, registrar") } },
            dismissButton = { TextButton(onClick = { pendiente = null }) { Text("Cancelar") } }
        )
    }
}

// ------------------------------------------------------------------ Historial

@Composable
fun Historial(vm: AppViewModel) {
    val tomas by vm.tomas.collectAsState()
    val meds by vm.medicamentos.collectAsState()
    var editando by remember { mutableStateOf<Toma?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ResumenExistencias(meds) }
        if (tomas.isEmpty()) item { Text("Aún no hay tomas registradas.", Modifier.padding(8.dp)) }
        items(tomas, key = { it.id }) { t ->
            FilaToma(t) { if (t.estado == "TOMADA") editando = t }
        }
    }

    editando?.let { t ->
        SensacionDialog(t, { editando = null }) { texto -> vm.guardarSensacion(t.id, texto); editando = null }
    }
}

@Composable
fun SensacionDialog(t: Toma, cerrar: () -> Unit, guardar: (String?) -> Unit) {
    var chip by remember { mutableStateOf("") }
    var texto by remember { mutableStateOf(t.sensacion ?: "") }
    AlertDialog(
        onDismissRequest = cerrar,
        title = { Text("¿Cómo te sentiste?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${t.nombreMedicamento} · ${fmtCompleto.format(Date(t.fechaHora))}")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    opcionesSentir.forEach {
                        FilterChip(
                            selected = chip == it,
                            onClick = { chip = if (chip == it) "" else it },
                            label = { Text(it) }
                        )
                    }
                }
                OutlinedTextField(texto, { texto = it }, label = { Text("Comentario (opcional)") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                guardar(listOf(chip, texto.trim()).filter { it.isNotBlank() }.joinToString(" - ").ifBlank { null })
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = cerrar) { Text("Cancelar") } }
    )
}

@Composable
fun ResumenExistencias(meds: List<Medicamento>) {
    if (meds.isNotEmpty()) {
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Pastillas que te quedan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                meds.forEach { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(m.nombre)
                        Text(
                            "${m.existencias} pastillas",
                            fontWeight = FontWeight.Bold,
                            color = if (m.existencias <= m.pastillasPorToma * 3) Rojo else Color.Unspecified
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FilaToma(t: Toma, alTocar: () -> Unit) {
    val tomada = t.estado == "TOMADA"
    ElevatedCard(onClick = alTocar, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${t.nombreMedicamento} · ${t.dosis}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Etiqueta(if (tomada) "Tomada" else "Omitida", if (tomada) Verde else Rojo)
            }
            Text(fmtCompleto.format(Date(t.fechaHora)), style = MaterialTheme.typography.bodySmall)
            if (t.fueraDeHorario) Etiqueta("Fuera de horario", Naranja)
            t.motivoOmision?.let { Text("Motivo: $it", style = MaterialTheme.typography.bodyMedium) }
            t.sensacion?.let { Text("Me sentí: $it", style = MaterialTheme.typography.bodyMedium) }
            if (tomada && t.sensacion == null) {
                Text(
                    "Toca para registrar cómo te sentiste",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (t.existenciasRestantes >= 0) {
                Text(
                    "Quedan ${t.existenciasRestantes} pastillas",
                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
