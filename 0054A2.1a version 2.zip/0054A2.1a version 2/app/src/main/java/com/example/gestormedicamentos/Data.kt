package com.example.gestormedicamentos

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

@Entity(tableName = "medicamentos")
data class Medicamento(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val idUsuario: Long = 1,
    val nombre: String,
    val tipo: String = "",          // lo escribe el usuario (ej. antibiótico, analgésico)
    val dosis: String,              // ej. "500 mg"
    val existencias: Int,           // pastillas disponibles
    val existenciasIniciales: Int = 0,  // para la barra de existencias
    val pastillasPorToma: Int = 1,  // cantidad que se descuenta por toma
    val horaProgramada: String      // "HH:mm"
)

@Entity(
    tableName = "tomas",
    foreignKeys = [ForeignKey(
        entity = Medicamento::class, parentColumns = ["id"],
        childColumns = ["idMedicamento"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("idMedicamento")]
)
data class Toma(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val idUsuario: Long = 1,
    val idMedicamento: Long,
    val nombreMedicamento: String,
    val dosis: String,
    val fechaHora: Long,
    val estado: String,             // "TOMADA" u "OMITIDA"
    val motivoOmision: String? = null,
    val fueraDeHorario: Boolean = false,
    val sensacion: String? = null,
    val existenciasRestantes: Int = -1  // pastillas que quedaron después de esta toma
)

fun esFueraDeHorario(horaProgramada: String, fechaHora: Long): Boolean {
    val (h, m) = horaProgramada.split(":").map { it.toInt() }
    val c = Calendar.getInstance().apply { timeInMillis = fechaHora }
    val diff = Math.abs((c[Calendar.HOUR_OF_DAY] * 60 + c[Calendar.MINUTE]) - (h * 60 + m))
    return minOf(diff, 1440 - diff) > 30
}

@Dao
abstract class AppDao {
    @Insert abstract suspend fun insertarMedicamento(m: Medicamento): Long
    @Insert abstract suspend fun insertarToma(t: Toma): Long

    @Query("SELECT * FROM medicamentos ORDER BY nombre")
    abstract fun medicamentos(): Flow<List<Medicamento>>

    @Query("SELECT * FROM medicamentos")
    abstract suspend fun listaMedicamentos(): List<Medicamento>

    @Query("UPDATE tomas SET sensacion = :s WHERE id = :id")
    abstract suspend fun actualizarSensacion(id: Long, s: String?)

    @Query("UPDATE medicamentos SET existencias = existencias + :n, existenciasIniciales = MAX(existenciasIniciales, existencias + :n) WHERE id = :id")
    abstract suspend fun reponer(id: Long, n: Int)

    @Query("SELECT * FROM medicamentos WHERE id = :id")
    abstract suspend fun medicamento(id: Long): Medicamento?

    @Query("SELECT * FROM tomas ORDER BY fechaHora DESC")
    abstract fun tomas(): Flow<List<Toma>>

    @Query("UPDATE medicamentos SET existencias = :e WHERE id = :id")
    abstract suspend fun actualizarExistencias(id: Long, e: Int)

    /** Devuelve null si todo salió bien, o el mensaje de error. */
    @Transaction
    open suspend fun registrarToma(t: Toma): String? {
        val m = medicamento(t.idMedicamento) ?: return "El medicamento no existe"
        var restantes = m.existencias
        if (t.estado == "TOMADA") {
            if (m.existencias < m.pastillasPorToma) return "No hay existencias suficientes"
            restantes = m.existencias - m.pastillasPorToma
            actualizarExistencias(m.id, restantes)
        }
        insertarToma(t.copy(existenciasRestantes = restantes))
        return null
    }
}

@Database(entities = [Medicamento::class, Toma::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var instancia: AppDatabase? = null
        fun get(c: Context): AppDatabase = instancia ?: synchronized(this) {
            instancia ?: Room.databaseBuilder(c.applicationContext, AppDatabase::class.java, "gestor.db")
                .fallbackToDestructiveMigration().build().also { instancia = it }
        }
    }
}
