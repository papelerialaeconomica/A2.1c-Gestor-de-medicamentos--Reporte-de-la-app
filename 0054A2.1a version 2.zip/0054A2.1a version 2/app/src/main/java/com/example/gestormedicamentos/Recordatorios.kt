package com.example.gestormedicamentos

import android.app.*
import android.content.*
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.util.Calendar

/** Milisegundos que faltan para la próxima vez que toca el medicamento (todos los días a la misma hora). */
fun msHastaProximaToma(horaProgramada: String, ahora: Long): Long {
    val (h, m) = horaProgramada.split(":").map { it.toInt() }
    val cal = Calendar.getInstance().apply {
        timeInMillis = ahora
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= ahora) add(Calendar.DAY_OF_YEAR, 1)
    }
    return cal.timeInMillis - ahora
}

fun textoTiempoRestante(ms: Long): String {
    val min = ms / 60000
    val h = min / 60
    val m = min % 60
    return when {
        h > 0 -> "$h h $m min"
        min > 0 -> "$min min"
        else -> "menos de 1 min"
    }
}

object Recordatorios {
    const val CANAL = "tomas"

    fun crearCanal(c: Context) {
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CANAL, "Recordatorios de tomas", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisa cuando te toca tomar tu medicamento"
            }
        )
    }

    fun programar(c: Context, m: Medicamento) {
        val momento = System.currentTimeMillis() + msHastaProximaToma(m.horaProgramada, System.currentTimeMillis())
        val pi = PendingIntent.getBroadcast(
            c, m.id.toInt(),
            Intent(c, RecordatorioReceiver::class.java).putExtra("idMed", m.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = c.getSystemService(AlarmManager::class.java)
        val exacta = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exacta) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, momento, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, momento, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, momento, pi)
        }
    }

    fun mostrarNotificacion(c: Context, m: Medicamento) {
        val confirmar = PendingIntent.getBroadcast(
            c, m.id.toInt(),
            Intent(c, ConfirmarTomaReceiver::class.java).putExtra("idMed", m.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val abrir = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(c, CANAL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Hora de tu medicamento")
            .setContentText("${m.nombre} - ${m.dosis} · Quedan ${m.existencias} pastillas")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(abrir)
            .addAction(0, "Ya la tomé", confirmar)
            .setAutoCancel(true)
            .build()
        try { c.getSystemService(NotificationManager::class.java).notify(m.id.toInt(), n) }
        catch (_: SecurityException) { }
    }

    suspend fun programarTodos(c: Context) {
        AppDatabase.get(c).dao().listaMedicamentos().forEach { programar(c, it) }
    }
}

class RecordatorioReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("idMed", -1)
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            val m = AppDatabase.get(c).dao().medicamento(id)
            if (m != null) {
                Recordatorios.mostrarNotificacion(c, m)
                Recordatorios.programar(c, m) // reprograma para el día siguiente
            }
            pr.finish()
        }
    }
}

class ConfirmarTomaReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("idMed", -1)
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.get(c).dao()
            val m = dao.medicamento(id)
            val error = if (m == null) "El medicamento no existe" else {
                val ahora = System.currentTimeMillis()
                dao.registrarToma(
                    Toma(
                        idMedicamento = m.id, nombreMedicamento = m.nombre, dosis = m.dosis,
                        fechaHora = ahora, estado = "TOMADA",
                        fueraDeHorario = esFueraDeHorario(m.horaProgramada, ahora)
                    )
                )
            }
            c.getSystemService(NotificationManager::class.java).cancel(id.toInt())
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(c, error ?: "Toma registrada correctamente", Toast.LENGTH_SHORT).show()
            }
            pr.finish()
        }
    }
}

/** Vuelve a programar los recordatorios después de reiniciar el celular. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            val pr = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                Recordatorios.programarTodos(c)
                pr.finish()
            }
        }
    }
}
